package com.cg.ams.test;

import static org.junit.Assert.*;
import java.util.HashMap;
import org.junit.Before;
import org.junit.Test;

import com.cg.ams.bean.Asset;
import com.cg.ams.bean.Request;
import com.cg.ams.dao.*;
import com.cg.ams.exception.AdminException;
import com.cg.ams.service.AdminServiceImpl;



public class AdminTestCase {

	AdminServiceImpl service = new AdminServiceImpl();
	AdminDao dao = new AdminDaoImpl();
	@Before
	 public void init()
	{
		service.setDao(dao);
	}
	
	@Test
	public void testAddAssetPass() throws AdminException {
		Asset asset = new Asset();
		asset.setAssetId(107);
		asset.setAssetName("ANDROID PHONES");
		asset.setAssetDes(" UPDATED VERSION I.E. MARSHMALLOW");
		asset.setAssetQuantity(81);
		asset.setAssetStatus("AVAILABLE");
		boolean flag= dao.addAsset(asset);
		assertEquals(flag,"true");
		//fail("Not yet implemented");
	}
	@Test(expected=AdminException.class)
	public void testAddAssetFail() throws AdminException {
		Asset asset = new Asset();
		asset.setAssetId(105);
		asset.setAssetName("ABC");
		asset.setAssetDes(" UPDATED VERSION I.E. MARSHMALLOW");
		asset.setAssetQuantity(81);
		asset.setAssetStatus("AVAILABLE");
		boolean flag= dao.addAsset(asset);
		
		assertEquals(flag,"true");
		//fail("Not yet implemented");
	}

	@Test(expected=AdminException.class)
	public void testModifyAssetPass() throws AdminException {
		Asset asset = new Asset();
		//dao.modifyAsset(asset);
		asset.setAssetId(104);
		asset.setAssetName("Keyboard");
		asset.setAssetDes("abcd");
		asset.setAssetQuantity(100);
		asset.setAssetStatus(" AVAILABLE");
		boolean flag= dao.modifyAsset(asset);
		
		assertEquals(flag,"true");
		
		
		
		
		//fail("Not yet implemented");
	}

	@Test(expected=AdminException.class)
	public void testModifyAssetFail() throws AdminException {
		Asset asset = new Asset();
	//	dao.modifyAsset(asset);
		asset.setAssetId(104);
		asset.setAssetName("Keyboard");
		asset.setAssetDes(" WIRELESS WITH WHISPER QUIET KEYS");
		asset.setAssetQuantity(90);
		asset.setAssetStatus("PENDING");
		boolean flag= dao.modifyAsset(asset);
		
		assertEquals(flag,"true");
		
		
		//fail("Not yet implemented");
	}
	@Test
	public void testViewAllRequestPass() throws AdminException {
		HashMap<Integer,Request>map = dao.viewAllRequest();
		assertNotNull(map);
		//fail("Not yet implemented");
	}

	@Test
	public void testViewAllRequestFail() throws AdminException {
		HashMap<Integer,Request>map = dao.viewAllRequest();
		assertNotNull(map);
		//fail("Not yet implemented");
	}
}
