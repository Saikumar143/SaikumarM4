package com.cg.ams.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import oracle.jdbc.pool.OracleDataSource;

public class DBUtil 
{
	public static Connection getConnect() throws SQLException 
	{
		
		InitialContext icontext ;
		DataSource ds ;
		Connection con = null; 
		try 
		{
			icontext = new InitialContext();
			ds=(DataSource)icontext.lookup("java:/OracleDS") ;
			con=ds.getConnection();
			System.out.println("Util Conection "+con);
			return con ;
		}
		
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		return con ;
	}
}
