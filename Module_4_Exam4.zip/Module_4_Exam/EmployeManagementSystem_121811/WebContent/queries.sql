create table employee (employee_code number primary key,employee_name varchar2(40),employee_gender varchar2(10),
designation_name varchar2(40),employee_email varchar2(30),employee_phone number(10));

create sequence hibernate_sequence start with 1000 increment by 1;

select hibernate_sequence.nextVal from dual
commit;

drop sequence hibernate_sequence

select * from employee

delete from employee where employee_code =952

drop table employee