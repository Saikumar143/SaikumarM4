/*********************************************************************
* File : EmployeeDAOImpl
* Author Name : Suraj Parmar
* Description : This File Is Responsible For Handling All The Business Logic 
* Version : 1.0
* Last Modified Date : 31/03/2017
* Change Description : N/A
*********************************************************************/



package com.capgemini.ems.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.capgemini.ems.entities.Employee;
import com.capgemini.ems.exception.EmployeeManagementException;

@Repository
public class EmployeeDAOImpl implements IEmployeeDAO 
{
	@PersistenceContext
	private EntityManager entityManager;
	
	

	public EmployeeDAOImpl() {
		
	}


	public EmployeeDAOImpl(EntityManager entityManager) {
		super();
		this.entityManager = entityManager;
	}

	

	public EntityManager getEntityManager() {
		return entityManager;
	}


	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}


	@Override
	public int addEmployee(Employee employee) throws EmployeeManagementException 
	{
		int employee_code = -1;
		
		try 
		{
			entityManager.persist(employee);
			employee_code = employee.getEmployee_code();
		}
		catch (Exception e) 
		{
			throw new EmployeeManagementException("Unable To Add Employee");
		}
		
		
		return employee_code;
	}

	@Override
	public List<Employee> getAllEmployees() throws EmployeeManagementException 
	{
		List<Employee> eList = new ArrayList<Employee>();
		
		try
		{
			eList = entityManager.createQuery("select e from Employee e").getResultList();
		} 
		catch (Exception e)
		{
			throw new EmployeeManagementException(e.getMessage());
		}
		return eList;
	}

}
