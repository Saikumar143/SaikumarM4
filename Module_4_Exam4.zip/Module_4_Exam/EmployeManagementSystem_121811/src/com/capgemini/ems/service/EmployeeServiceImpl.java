/*********************************************************************
* File : EmployeeServiceImpl
* Author Name : Suraj Parmar
* Description : This File Is Responsible For Sending Results Of The Methods To DAO
* Version : 1.0
* Last Modified Date : 31/03/2017
* Change Description : N/A
*********************************************************************/

package com.capgemini.ems.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.ems.dao.IEmployeeDAO;
import com.capgemini.ems.entities.Employee;
import com.capgemini.ems.exception.EmployeeManagementException;

@Service
@Transactional
public class EmployeeServiceImpl implements IEmployeeService
{
	@Autowired
	private IEmployeeDAO employeeDAO;
	
	
	public EmployeeServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	public IEmployeeDAO getEmployeeDAO() {
		return employeeDAO;
	}



	public void setEmployeeDAO(IEmployeeDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
	}



	public EmployeeServiceImpl(IEmployeeDAO employeeDAO) {
		super();
		this.employeeDAO = employeeDAO;
	}



	@Override
	public int addEmployee(Employee employee)
			throws EmployeeManagementException {
		// TODO Auto-generated method stub
		return employeeDAO.addEmployee(employee);
	}

	@Override
	public List<Employee> getAllEmployees() throws EmployeeManagementException {
		// TODO Auto-generated method stub
		return employeeDAO.getAllEmployees();
	}
	
}
