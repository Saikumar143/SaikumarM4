/*********************************************************************
* File : IEmployeeService
* Author Name : Suraj Parmar
* Description : This File Contains List Of Methods Which Are Same As That Of The File "IEmployeeDAO"
* Version : 1.0
* Last Modified Date : 31/03/2017
* Change Description : N/A
*********************************************************************/

package com.capgemini.ems.service;

import java.util.List;

import com.capgemini.ems.entities.Employee;
import com.capgemini.ems.exception.EmployeeManagementException;

public interface IEmployeeService 
{
	public int addEmployee(Employee employee) throws EmployeeManagementException;
	public List<Employee> getAllEmployees() throws EmployeeManagementException;
}
