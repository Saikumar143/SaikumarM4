create sequence custId_seq start with 1000;

select * from customerDetails;

create table gymCustomer 
(
	id number primary key,
	name varchar2(20) ,
	age number ,
	gym varchar2(20) ,
	timings varchar2(20) 
)

select * from gymCustomer;

select custId_seq.nextval from dual ;