package com.capgemini.gym.dao;

import com.capgemini.gym.entities.Customer;
import com.capgemini.gym.exception.BookingException;

public interface IBookingDAO 
{
	public int addCustomer(Customer customer) throws BookingException;
	public Customer getCustomer(int id ) throws BookingException ;
	public void updateCustomer(Customer customer) throws BookingException ;
}
