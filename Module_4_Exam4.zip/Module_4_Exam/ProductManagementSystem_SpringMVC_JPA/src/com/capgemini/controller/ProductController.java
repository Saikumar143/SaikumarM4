package com.capgemini.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.entities.Product;
import com.capgemini.service.IProductService;

@Controller
public class ProductController 
{
	@Autowired
	IProductService ProductService;

	public ProductController() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProductController(IProductService productService) {
		super();
		ProductService = productService;
	}

	public IProductService getProductService() {
		return ProductService;
	}

	public void setProductService(IProductService productService) {
		ProductService = productService;
	}
	
	@RequestMapping("home")
	public String getHomePage()
	{
		return "HomePage";
	}

	@RequestMapping("addproduct")
	public String getAddProductPage(Model model)
	{
		List<String> categories = new ArrayList<>();
		categories.add("shoes");
		categories.add("Electronics");
		categories.add("clothes");
		categories.add("Books");
		
		
		//Add the form product backing bean to be binded AddProduct.jsp form
		model.addAttribute("product", new Product());
		
		model.addAttribute("categories",categories);
		
		return "AddProductPage";
	}
	
	@RequestMapping(value="ProcessAddProductForm")
	public ModelAndView ProcessAddProductForm(@ModelAttribute("product") @Valid Product product, BindingResult result
			,Model  model)
		{ 
			if(result.hasErrors() == true)
			{
				List<String> categories = new ArrayList<>();
				categories.add("shoes");
				categories.add("Electronics");
				categories.add("clothes");
				categories.add("Books");
				
				
				//Add the form product backing bean to be binded AddProduct.jsp form
				model.addAttribute("product",  product);
				
				model.addAttribute("categories",categories);
				
				return new ModelAndView("AddProductPage");
			}
	        int productId= -1;
	        
			try
			{
			    productId = ProductService.addProduct(product);
				model.addAttribute("message", "Product Added successfully"+productId);
				return new ModelAndView("SuccessPage");
			}
			catch (Exception e)
			{
				model.addAttribute("errMsg", "Could Not Add Product Reason:" +e.getMessage());
				return new ModelAndView("SuccessPage");
			}
		}
	@RequestMapping("getproduct")
	public String getProductPage()
	{
		return "GetProductPage";
	}
	
	@RequestMapping("processgetproductform")
	public ModelAndView ProcessGetProductForm(@RequestParam("productId") int pid)
	{
		Product product = null;
		try
		{
			product = ProductService.getProduct(pid);
			
			return new ModelAndView("GetProductPage","product",product);
		}
		catch(Exception e)
		{
			return new ModelAndView("ErrorPage","errMsg", "could not retriev product Reason:"+e.getMessage());
		}
	}
	@RequestMapping("viewallproduct")
	public String getViewAllProductPage(Model model)
	{
		List<Product>products = null;
		try
		{
			products = ProductService.getAllProducts();
			model.addAttribute("products", products);
		}
		catch(Exception e)
		{
			model.addAttribute("errMsg","could not retriev product Reason"+e.getMessage());
			
			return "ErrorPage";
		}
		return "ViewAllProductPage";
	}
	
	@RequestMapping("getupdatepage")
	public String getUpdatePage(@RequestParam("pid") int id, Model model)
	{
		List<String> categories = new ArrayList<>();
		categories.add("shoes");
		categories.add("Electronics");
		categories.add("clothes");
		categories.add("Books");
		
		Product product = null;
		try
		{
			product = ProductService.getProduct(id);
		}
		catch(Exception e)
		{
			model.addAttribute("errMsg","could not retriev product Reason"+e.getMessage());
			return "ErrorPage";
		}
		
		
		//Add the form product backing bean to be binded AddProduct.jsp form
		model.addAttribute("product", product);
		
		model.addAttribute("categories",categories);
		
		return "UpdatePage";
	}
	
	@RequestMapping(value="ProcessUpdatePageForm", method=RequestMethod.POST)
	public String ProcessUpdatePageForm(@ModelAttribute("product")@Valid Product product, BindingResult result, Model model)
	{
		if( result.hasErrors() == true )
		{
			List<String> categories = new ArrayList<>();
			categories.add("shoes");
			categories.add("Electronics");
			categories.add("clothes");
			categories.add("Books");
			
			
			//Add the form product backing bean to be binded AddProduct.jsp form
			model.addAttribute("product",  product);
			
			model.addAttribute("categories",categories);
			
			return "UpdatePage";
			
		}
		
		try
		{
			ProductService.updateProduct(product);
		}
		catch(Exception e)
		{
			model.addAttribute("errMsg","could not retriev product Reason"+e.getMessage());
			
			return "ErrorPage";
		}
		model.addAttribute("message","Product Updated Successfully");
		return "SuccessPage";
	}
}
	
	
	
	

