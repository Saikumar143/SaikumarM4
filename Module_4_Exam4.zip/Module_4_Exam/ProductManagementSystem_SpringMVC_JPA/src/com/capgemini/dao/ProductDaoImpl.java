package com.capgemini.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.entities.Product;
import com.capgemini.exception.ProductException;


@Repository("productDAO")
public class ProductDaoImpl implements IProductDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	public ProductDaoImpl() {
		
	}
	
	
	@Override
	public int addProduct(Product product) throws ProductException {
		
		int productId=0;
		try{
		
			
			entityManager.persist(product);
			
			productId=product.getId();
			
		
		}
		catch(Exception e)
		{
			
			throw new ProductException(e.getMessage());
		}
		return productId;
	}

	@Override
	public void updateProduct(Product product) throws ProductException {
	
		try{
			
			
			entityManager.merge(product);
			entityManager.flush();
			
		
		}
		catch(Exception e)
		{
			
			throw new ProductException(e.getMessage());
		}
		

	}

	@Override
	public Product getProduct(int id) throws ProductException {
		
		Product product=null;
	try{
			
			
			product=entityManager.find(Product.class,id);
			entityManager.flush();
			
		
		}
		catch(Exception e)
		{
			
			throw new ProductException(e.getMessage());
		}
		if(product==null)
		{
			throw new ProductException("No Product found with id="+id);
		}
	
		return product;
	}

	@Override
	public void removeProduct(int id) throws ProductException {
		
		try{
			
		
			Product product=entityManager.find(Product.class, id);
			entityManager.remove(product);
			
		
		}
		catch(Exception e)
		{
			throw new ProductException(e.getMessage());
		}

	}


	@Override
	public List<Product> getAllProducts() throws ProductException {
		
		List<Product> products=null;
		try{
			
			
			
			TypedQuery<Product> tQuery=entityManager.createNamedQuery("GetAllProducts",Product.class);
			products=tQuery.getResultList();
			
			
		
			
		}
		catch(Exception e)
		{
			
			throw new ProductException(e.getMessage());
		}
		if(products==null || products.isEmpty())
			throw new ProductException("No Products to display");
		return products;
	}


	@Override
	public Product getProductByName(String name) throws ProductException {
		
		Product products=null;
try{
			
			
			
			TypedQuery<Product> tQuery=entityManager.createQuery("select p from Product p where p.name=:pname",Product.class);
			tQuery.setParameter("pname", name);
			products=tQuery.getSingleResult();
			
		
			
		}
		catch(Exception e)
		{

			throw new ProductException(e.getMessage());
		}
		return products;
	}


	@Override
	public List<Product> getProductsByRange(float min, float max){
	List<Product> products=null;
	try{
		

		
		TypedQuery<Product> tQuery=entityManager.createQuery("select p from Product p where p.price between :pmin and :pmax",Product.class);
		tQuery.setParameter("pmin", min);
		tQuery.setParameter("pmax", max);
		products=tQuery.getResultList();
		
		entityManager.getTransaction().commit();
	
		
	}
	catch(Exception e)
	{
		
		throw new ProductException(e.getMessage());
	}
	if(products==null || products.isEmpty())
		throw new ProductException("No Products to display");
	return products;
	}

}
