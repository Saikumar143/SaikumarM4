package com.capgemini.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table(name="ProductDetails")
@NamedQueries(
		@NamedQuery(name="GetAllProducts",query="select p from Product p")
		)
public class Product {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="myseqgen")
	@SequenceGenerator(name ="myseqgen", sequenceName="productId_seq", initialValue=1000)
	@Column(name="pid")
	private int id;
	
	@NotEmpty(message="Name cannot be empty")
	@Column(name="pname" ,nullable=false)
	private String name;
	
	@Min(value=1, message="quantity cannot be less than zero")
	@Column(name="pquantity" ,nullable=false)
	private int quantity;
	
	@NotEmpty(message="category cannot be empty")
	@Column(name="category", nullable=false)
	private String category;
	
	@Min(value=10,message="product price canot be less than 10")
	@Column(name="price", nullable=false)
	private float price;

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Product(int id, String name, int quantity, String category,
			float price) {
		super();
		this.id = id;
		this.name = name;
		this.quantity = quantity;
		this.category = category;
		this.price = price;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", quantity="
				+ quantity + ", category=" + category + ", price=" + price
				+ "]";
	}

	
	public Product(String name, int quantity, String category, float price) {
		super();
		this.name = name;
		this.quantity = quantity;
		this.category = category;
		this.price = price;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (id != other.id)
			return false;
		return true;
	}
	
	
}
