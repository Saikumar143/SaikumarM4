package com.capgemini.DAO;

import java.util.List;

import com.capgemini.entities.Trainee;
import com.capgemini.exception.TraineeException;

public interface ITraineeDAO 
{

		public int addTrainee(Trainee trainee) throws TraineeException;
		public Trainee getTrainee(int tid) throws TraineeException;
		public void UpdateTrainee(Trainee trainee) throws TraineeException;
		public List<Trainee> getAllTrainee() throws TraineeException;
		public void removeTrainee(int tid) throws TraineeException;
		
}
