package com.capgemini.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.DAO.ITraineeDAO;
import com.capgemini.entities.Trainee;
import com.capgemini.exception.TraineeException;


@Transactional
@Service("traineeService")
public class TraineeServiceImpl implements ITraineeService 
{
	@Autowired
	ITraineeDAO traineeDAO ;
	
	public TraineeServiceImpl() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	@Override
	public String toString() {
		return "TraineeServiceImpl [traineeDAO=" + traineeDAO + "]";
	}



	public ITraineeDAO getTraineeDAO() {
		return traineeDAO;
	}



	public void setTraineeDAO(ITraineeDAO traineeDAO) {
		this.traineeDAO = traineeDAO;
	}



	public TraineeServiceImpl(ITraineeDAO traineeDAO) {
		super();
		this.traineeDAO = traineeDAO;
	}



	@Override
	public int addTrainee(Trainee trainee) throws TraineeException {
		
		return traineeDAO.addTrainee(trainee);
	}

	@Override
	public Trainee getTrainee(int tid) throws TraineeException {
		
		return traineeDAO.getTrainee(tid);
	}

	@Override
	public void UpdateTrainee(Trainee trainee) throws TraineeException {
	
		traineeDAO.UpdateTrainee(trainee);

	}

	@Override
	public List<Trainee> getAllTrainee() throws TraineeException {
		
		return traineeDAO.getAllTrainee();
	}

	@Override
	public void removeTrainee(int tid) throws TraineeException {
		traineeDAO.removeTrainee(tid);
		

	}

}
